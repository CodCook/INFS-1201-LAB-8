##Mahgoub Mohamed
##60304062

def scalarAdd(lst,num):
    '''Add a number to all elements of the list.'''
    return [i+num for i in lst]
